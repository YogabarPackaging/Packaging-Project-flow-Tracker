const fs = require('fs');
const path = require('path');
const rootDir = 'C:\\app-package';
const archiver = require(path.join(rootDir, 'server', 'node_modules', 'archiver'));
const targetZip = 'C:\\app-package\\Packaging-Project-flow-Tracker-Complete.zip';

console.log('📦 Creating 100% Windows Explorer compatible PKZIP archive...');

// Remove old zip if exists
if (fs.existsSync(targetZip)) {
  fs.unlinkSync(targetZip);
}

const output = fs.createWriteStream(targetZip);
const archive = archiver('zip', {
  zlib: { level: 6 }, // standard deflate compression level
  forceLocalTime: true // uses standard MS-DOS timestamp format for Windows Explorer
});

output.on('close', () => {
  const sizeMb = (archive.pointer() / (1024 * 1024)).toFixed(2);
  console.log(`✅ Archive finalized successfully: ${sizeMb} MB (${archive.pointer()} bytes)`);
  console.log(`📍 Location: ${targetZip}`);
});

archive.on('warning', (err) => {
  if (err.code === 'ENOENT') {
    console.warn('Archive warning:', err);
  } else {
    throw err;
  }
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// 1. Root files
const rootFiles = [
  'package.json',
  'package-lock.json',
  '.gitignore',
  'README.md',
  'SECURITY.md',
  'RELEASE_CHECKLIST.md',
  'ecosystem.config.cjs',
  'App tables.xlsx',
  'Packaging_Development_Tracker_Authority_Guide.docx'
];

for (const file of rootFiles) {
  const fullPath = path.join(rootDir, file);
  if (fs.existsSync(fullPath)) {
    archive.file(fullPath, { name: file });
  }
}

// 2. Directories (client, server, docs, scratch)
// client
archive.glob('**/*', {
  cwd: path.join(rootDir, 'client'),
  ignore: ['node_modules/**', 'dist/**', 'client/**'],
  dot: true
}, { prefix: 'client' });

// server
archive.glob('**/*', {
  cwd: path.join(rootDir, 'server'),
  ignore: ['node_modules/**', 'uploads/**', 'backups/**', 'data/local_store_backup.json'],
  dot: true
}, { prefix: 'server' });

// docs
if (fs.existsSync(path.join(rootDir, 'docs'))) {
  archive.directory(path.join(rootDir, 'docs'), 'docs');
}

// scratch
archive.glob('**/*', {
  cwd: path.join(rootDir, 'scratch'),
  ignore: ['edge_profile/**'],
  dot: true
}, { prefix: 'scratch' });

archive.finalize();
